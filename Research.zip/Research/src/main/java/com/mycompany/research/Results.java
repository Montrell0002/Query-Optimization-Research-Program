/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.research;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.DefaultListModel;

/**
 *
 * @author Dell Inspiron 14
 */
public class Results extends javax.swing.JFrame {


    public Results(String selection, int number) {
        initComponents();
        jLabel10.setText(selection);
        jLabel8.setText(String.valueOf(number));
        String subj= selection;
        if (subj =="Subquery vs. JOIN"){
            subject_1(number);
            subject_11(number);
        }
        if (subj =="SELECT * vs. Specific Columns"){
            subject_2(number);
            subject_22(number);
        }
        if (subj =="JOIN and Filtering"){
            subject_3(number);
            subject_33(number);
        }
        if (subj =="Indexed vs. Non-Indexed"){
            subject_4(number);
            subject_44(number);
        }
        if (subj =="IN Subquery vs. JOINs"){
            subject_5(number);
            subject_55(number);
        }
        if (subj =="Subquery vs. GROUP BY"){
            subject_6(number);
            subject_66(number);
        }
        
        
    }
    
    
    private void subject_1(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT first_name, last_name, email FROM students WHERE student_id <= ? AND student_id IN (SELECT student_id FROM enrollments WHERE course_id IN (SELECT course_id FROM courses WHERE department_id = 1)); ";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("first_name") + " " + rs.getString("last_name")+ " |" + rs.getString("email");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace(); 
}
    
}
    private void subject_11(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT DISTINCT s.first_name, s.last_name, s.email FROM students s JOIN enrollments e ON s.student_id = e.student_id JOIN courses c ON e.course_id = c.course_id WHERE c.department_id = 1 AND s.student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("s.first_name") + " " + rs.getString("s.last_name")+ " |" + rs.getString("s.email");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime));
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_2(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT * FROM students WHERE major = 'Computer Science' AND student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("first_name") + " " + rs.getString("last_name")+ "| " + rs.getInt("age") +"| " + rs.getString("gender") +"| " + rs.getString("major") +"| " + rs.getDouble("gpa") +" |" + rs.getString("city") +"| " + rs.getString("state") +" |" + rs.getString("email");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace(); 
}
    
}
    private void subject_22(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT student_id, first_name, last_name, gpa FROM students WHERE major = 'Computer Science' AND student_id <= ? ;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getInt("student_id") + "| " + rs.getString("first_name")+ " " + rs.getString("last_name")+ "| " + rs.getDouble("gpa");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime));
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_3(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT s.first_name, s.last_name, c.course_name FROM students s JOIN enrollments e ON s.student_id = e.student_id JOIN courses c ON e.course_id = c.course_id WHERE c.department_id = 1 AND s.state = 'NC' AND s.student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("s.first_name")+ " " + rs.getString("s.last_name")+ "| " + rs.getString("c.course_name");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_33(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT s.first_name, s.last_name, c.course_name FROM students s JOIN enrollments e ON s.student_id = e.student_id JOIN courses c ON e.course_id = c.course_id WHERE s.state = 'NC' AND c.department_id = 1 AND s.student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("s.first_name")+ " " + rs.getString("s.last_name")+ "| " + rs.getString("c.course_name");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime));
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_4(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT * FROM students WHERE last_name = 'Smith' AND student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("first_name") + " " + rs.getString("last_name")+ "| " + rs.getInt("age") +"| " + rs.getString("gender") +"| " + rs.getString("major") +"| " + rs.getDouble("gpa") +" |" + rs.getString("city") +"| " + rs.getString("state") +" |" + rs.getString("email");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace(); 
}
    
}
    private void subject_44(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "CREATE INDEX idx_students_last_name ON students(last_name); SELECT *FROM students WHERE last_name = 'Smith' AND student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("first_name") + " " + rs.getString("last_name")+ "| " + rs.getInt("age") +"| " + rs.getString("gender") +"| " + rs.getString("major") +"| " + rs.getDouble("gpa") +" |" + rs.getString("city") +"| " + rs.getString("state") +" |" + rs.getString("email");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime));
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace(); 
}
    
}
    private void subject_5(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT first_name, last_name\n" +
"FROM students\n" +
"WHERE student_id <= ? AND student_id IN (\n" +
"    SELECT student_id\n" +
"    FROM enrollments\n" +
"    WHERE course_id IN (\n" +
"        SELECT course_id\n" +
"        FROM courses\n" +
"        WHERE department_id = 1\n" +
"    )\n" +
");";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("s.first_name")+ " " + rs.getString("s.last_name");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_55(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT DISTINCT s.first_name, s.last_name\n" +
"FROM students s\n" +
"JOIN enrollments e\n" +
"    ON s.student_id = e.student_id\n" +
"JOIN courses c\n" +
"    ON e.course_id = c.course_id\n" +
"WHERE c.department_id = 1 AND s.student_id <= ?;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("s.first_name")+ " " + rs.getString("s.last_name");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime)+"s");
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_6(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT department_id,\n" +
"       (SELECT AVG(s.gpa)\n" +
"        FROM students s\n" +
"        WHERE s.student_id <= ? AND s.major = d.department_name) AS average_gpa\n" +
"FROM departments d;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel11.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("department_id")+ "| " + rs.getDouble("average_gpa");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel12.setText(Double.toString(responseTime));
    jList1.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}
    private void subject_66(int number){
        int size= number;
        DefaultListModel<String> model = new DefaultListModel<>();
        model.clear();
        try {
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/research",
        "root",
        "password"
    );

    String sql = "SELECT d.department_id,\n" +
"       d.department_name,\n" +
"       AVG(s.gpa) AS average_gpa\n" +
"FROM departments d\n" +
"JOIN students s \n" +
"    ON s.major = d.department_name WHERE s.student_id <= ?\n" +
"GROUP BY d.department_id, d.department_name;";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1,size);
    long exeStart= System.nanoTime();
    ResultSet rs = pst.executeQuery();
    long exeEnd= System.nanoTime();
    double executionTime = (exeEnd - exeStart) / 1000000.0;
    jLabel13.setText(Double.toString(executionTime));
    long respStart= System.nanoTime();
    while (rs.next()) {
        String missing = rs.getString("department_id")+ "| " + rs.getString("department_name")+ "| "+ rs.getDouble("average_gpa");
         model.addElement(missing);
    }
    long respEnd= System.nanoTime();
    double responseTime = (respEnd - respStart) / 1000000.0;
    jLabel14.setText(Double.toString(responseTime));
    jList2.setModel(model);
    
    } catch (Exception e) {
    e.printStackTrace();
}
        
    
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Unoptimized Query:");

        jLabel2.setText("Optimized Query:");

        jButton1.setText("Close");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Execution Time:");

        jLabel4.setText("Execution Time:");

        jLabel5.setText("Response Time:");

        jLabel6.setText("Response Time:");

        jLabel7.setText("Dataset Size:");

        jLabel8.setText("jLabel8");

        jLabel9.setText("Query Subject:");

        jLabel10.setText("jLabel10");

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList1);

        jList2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(jList2);

        jLabel11.setText("jLabel11");

        jLabel12.setText("jLabel12");

        jLabel13.setText("jLabel13");

        jLabel14.setText("jLabel14");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(310, 310, 310)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel12))
                            .addComponent(jLabel1)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jScrollPane4)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel13)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel14)
                                .addGap(0, 41, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)))
                .addGap(16, 16, 16))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(jLabel14))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel13))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel11))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(jLabel12)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addGap(19, 19, 19)
                .addComponent(jButton1)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jList1.clearSelection();
        jList2.clearSelection();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Results.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Results.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Results.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Results.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Results("Comp", 10).setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
