/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.research;
import java.sql.*;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Dell Inspiron 14
 */
public class Research extends javax.swing.JFrame {

    /**
     * Creates new form ResearchGUI
     */
    public Research() {
        initComponents();
        studentList();
    }
    private boolean studentsloaded1= false;
    private boolean departmentsloaded1= false;
    private boolean coursesloaded1= false;
    private boolean enrollmentsloaded1= false;
    
    private void studentList (){
         if (studentsloaded1) return;

    DefaultTableModel model = new DefaultTableModel();

    // Add table columns
    model.addColumn("Student ID");
    model.addColumn("First Name");
    model.addColumn("Last Name");
    model.addColumn("Age");
    model.addColumn("Gender");
    model.addColumn("Major");
    model.addColumn("GPA");
    model.addColumn("City");
    model.addColumn("State");
    model.addColumn("Email");

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/research",
            "root",
            "password"
        );

        String sql = "SELECT student_id, first_name, last_name, age, gender, "
                   + "major, gpa, city, state, email FROM students";

        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("student_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getInt("age"),
                rs.getString("gender"),
                rs.getString("major"),
                rs.getDouble("gpa"),
                rs.getString("city"),
                rs.getString("state"),
                rs.getString("email")
            });
        }

        // Put the model into JTable
        jTable1.setModel(model);

        studentsloaded1 = true;

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Failed");
    }
    }
    private void departmentList() {

    if (departmentsloaded1) return;

    DefaultTableModel model = new DefaultTableModel();

    model.addColumn("Department ID");
    model.addColumn("Department Name");

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/research",
            "root",
            "password"
        );

        String sql = "SELECT department_id, department_name FROM departments";

        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("department_id"),
                rs.getString("department_name")
            });
        }

        jTable1.setModel(model);

        departmentsloaded1 = true;

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Failed");
    }
}
    private void courseList() {

    if (coursesloaded1) return;

    DefaultTableModel model = new DefaultTableModel();

    model.addColumn("Course ID");
    model.addColumn("Course Name");
    model.addColumn("Department ID");
    model.addColumn("Credits");

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/research",
            "root",
            "password"
        );

        String sql = "SELECT course_id, course_name, department_id, credits FROM courses";

        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("course_id"),
                rs.getString("course_name"),
                rs.getInt("department_id"),
                rs.getInt("credits")
            });
        }

        jTable1.setModel(model);

        coursesloaded1 = true;

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Failed");
    }
}
    private void enrollmentList() {

    if (enrollmentsloaded1) return;

    DefaultTableModel model = new DefaultTableModel();

    model.addColumn("Enrollment ID");
    model.addColumn("Student ID");
    model.addColumn("Course ID");
    model.addColumn("Semester");
    model.addColumn("Grade");

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/research",
            "root",
            "password"
        );

        String sql = "SELECT enrollment_id, student_id, course_id, semester, grade "
                   + "FROM enrollments";

        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("enrollment_id"),
                rs.getInt("student_id"),
                rs.getInt("course_id"),
                rs.getString("semester"),
                rs.getString("grade")
            });
        }

        jTable1.setModel(model);

        enrollmentsloaded1 = true;

        rs.close();
        pst.close();
        con.close();

    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Failed");
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jButton1 = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jRadioButton4 = new javax.swing.JRadioButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Run Comparison");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Students", "Enrollment", "Departments", "Courses" }));
        jComboBox3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox3ItemStateChanged(evt);
            }
        });
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jLabel1.setText("Choose Table to View:");

        jLabel2.setText("Unoptimized Query:");

        jTextPane1.setEditable(false);
        jScrollPane2.setViewportView(jTextPane1);

        jTextPane2.setEditable(false);
        jScrollPane3.setViewportView(jTextPane2);

        jLabel3.setText("Optimized Query:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Type", "Subquery vs. JOIN", "SELECT * vs. Specific Columns", "JOIN and Filtering", "Indexed vs. Non-Indexed", "IN Subquery vs. JOINs", "Subquery vs. GROUP BY" }));
        jComboBox1.setAutoscrolls(true);
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("10,000");

        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setText("50,000");

        jLabel4.setText("Dataset Size:");

        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setText("100,000");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable1);

        jLabel5.setText("Choose Query Type:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 743, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(279, 279, 279)
                                        .addComponent(jRadioButton1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jRadioButton3)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(41, 41, 41)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jRadioButton4)))))
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(337, 337, 337))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(299, 299, 299))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(357, 357, 357))))
            .addGroup(layout.createSequentialGroup()
                .addGap(331, 331, 331)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addGap(5, 5, 5)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton3)
                    .addComponent(jRadioButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
        String selectedValue = jComboBox3.getSelectedItem().toString();
        
        if (selectedValue.equals("Students")){
            studentList();
            departmentsloaded1= false;
            coursesloaded1= false;
            enrollmentsloaded1= false;
        }
         if (selectedValue.equals("Departments")){
            departmentList();
            studentsloaded1= false;
            coursesloaded1= false;
            enrollmentsloaded1= false;
        }
          if (selectedValue.equals("Courses")){
            courseList();
            departmentsloaded1= false;
            studentsloaded1= false;
            enrollmentsloaded1= false;
        }
           if (selectedValue.equals("Enrollment")){
            enrollmentList();
            departmentsloaded1= false;
            coursesloaded1= false;
            studentsloaded1= false;
        }
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jComboBox3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox3ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ItemStateChanged

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        String selectedValue = jComboBox1.getSelectedItem().toString();
        
        if (selectedValue.equals("Subquery vs. JOIN")){
            jTextPane1.setText("SELECT first_name, last_name, email\n" +
"FROM students\n" +
"WHERE student_id IN (\n" +
"    SELECT student_id\n" +
"    FROM enrollments\n" +
"    WHERE course_id IN (\n" +
"        SELECT course_id\n" +
"        FROM courses\n" +
"        WHERE department_id = 1\n" +
"    )\n" +
");");
            jTextPane2.setText("SELECT DISTINCT s.first_name, s.last_name, s.email\n" +
"FROM students s\n" +
"JOIN enrollments e\n" +
"    ON s.student_id = e.student_id\n" +
"JOIN courses c\n" +
"    ON e.course_id = c.course_id\n" +
"WHERE c.department_id = 1;");
        }
        if (selectedValue.equals("SELECT * vs. Specific Columns")){
            jTextPane1.setText("SELECT *\n" +
"FROM students\n" +
"WHERE major = 'Computer Science';");
            jTextPane2.setText("SELECT student_id, first_name, last_name, gpa\n" +
"FROM students\n" +
"WHERE major = 'Computer Science';");
        }
        if (selectedValue.equals("JOIN and Filtering")){
            jTextPane1.setText("SELECT s.first_name, s.last_name, c.course_name\n" +
"FROM students s\n" +
"JOIN enrollments e\n" +
"    ON s.student_id = e.student_id\n" +
"JOIN courses c\n" +
"    ON e.course_id = c.course_id\n" +
"WHERE c.department_id = 1\n" +
"AND s.state = 'NC';");
            jTextPane2.setText("SELECT s.first_name, s.last_name, c.course_name\n" +
"FROM students s\n" +
"JOIN enrollments e\n" +
"    ON s.student_id = e.student_id\n" +
"JOIN courses c\n" +
"    ON e.course_id = c.course_id\n" +
"WHERE s.state = 'NC'\n" +
"AND c.department_id = 1;");
        }
        if (selectedValue.equals("Indexed vs. Non-Indexed")){
            jTextPane1.setText("SELECT *\n" +
"FROM students\n" +
"WHERE last_name = 'Smith';");
            jTextPane2.setText("CREATE INDEX idx_students_last_name\n" +
"ON students(last_name);\n" +
"\n" +
"SELECT *\n" +
"FROM students\n" +
"WHERE last_name = 'Smith';");
        }
        if (selectedValue.equals("IN Subquery vs. JOINs")){
            jTextPane1.setText("SELECT first_name, last_name\n" +
"FROM students\n" +
"WHERE student_id IN (\n" +
"    SELECT student_id\n" +
"    FROM enrollments\n" +
"    WHERE course_id IN (\n" +
"        SELECT course_id\n" +
"        FROM courses\n" +
"        WHERE department_id = 1\n" +
"    )\n" +
");");
            jTextPane2.setText("SELECT DISTINCT s.first_name, s.last_name\n" +
"FROM students s\n" +
"JOIN enrollments e\n" +
"    ON s.student_id = e.student_id\n" +
"JOIN courses c\n" +
"    ON e.course_id = c.course_id\n" +
"WHERE c.department_id = 1;");
        }
        if (selectedValue.equals("Subquery vs. GROUP BY")){
            jTextPane1.setText("SELECT department_id,\n" +
"       (SELECT AVG(s.gpa)\n" +
"        FROM students s\n" +
"        WHERE s.major = d.department_name) AS average_gpa\n" +
"FROM departments d;");
            jTextPane2.setText("SELECT d.department_id,\n" +
"       d.department_name,\n" +
"       AVG(s.gpa) AS average_gpa\n" +
"FROM departments d\n" +
"JOIN students s\n" +
"    ON s.major = d.department_name\n" +
"GROUP BY d.department_id, d.department_name;");
        }
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        // Get the selected ComboBox value as a String
        String selection = jComboBox1.getSelectedItem().toString();

        // Get the selected RadioButton value as an int
        int number = 0;

        if (jRadioButton1.isSelected()) {
            number = 10000;
        } else if (jRadioButton3.isSelected()) {
            number = 50000;
        } else if (jRadioButton4.isSelected()) {
            number = 100000;
        }

        // Open Results JFrame and pass the values
        Results results = new Results(selection, number);
        results.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Research.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Research.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Research.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Research.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Research().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    // End of variables declaration//GEN-END:variables
}
